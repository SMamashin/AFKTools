
--proc/controls/richedit: standard richedit control
--Written by Cosmin Apreutesei. Public Domain.

setfenv(1, require'winapi')

ffi.cdef[[
]]
